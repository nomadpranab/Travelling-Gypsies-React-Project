import React from 'react'

export default function Home() {
  return (
    <div className="bg-image">
        <span><h1 id="heading"style={{fontSize:'75px', textAlign:'center', marginTop:'10%'}}>INT252</h1></span>
    </div>
  )
}
